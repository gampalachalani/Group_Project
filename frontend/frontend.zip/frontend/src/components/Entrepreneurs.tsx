// import React from 'react'

export default function Entrepreneurs() {
  return (
    <div>Entrepreneurs</div>
  )
}
