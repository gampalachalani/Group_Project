//import React from 'react'

export default function Funding() {
    return (
      <div>Funding</div>
    )
  }