// import React from 'react'

export default function Investors() {
  return (
    <div>Investors</div>
  )
}
